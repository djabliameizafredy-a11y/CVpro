import React, { useState, useEffect } from 'react';
import { CVData } from './types';
import { sampleCVFr, sampleCVEn, emptyCVState } from './data/sampleCV';
import { evaluateAtsScore } from './data/aiHelpers';
import { Header } from './components/Header';
import { EditorPanel } from './components/EditorPanel';
import { CVPreview } from './components/CVPreview';
import { AtsCheckerModal } from './components/AtsCheckerModal';
import { exportToPdf, exportToImage } from './utils/exportHelpers';

const LOCAL_STORAGE_KEY = 'cv_builder_pro_data_v1';
const THEME_STORAGE_KEY = 'cv_builder_app_theme';

export default function App() {
  const [cv, setCv] = useState<CVData>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.personal) return parsed;
      } catch {
        // Fallback to sample data
      }
    }
    return sampleCVFr;
  });

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    return saved ? saved === 'dark' : true;
  });

  const [isAtsModalOpen, setIsAtsModalOpen] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isExportingImage, setIsExportingImage] = useState(false);

  // Auto save CV to local storage
  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(cv));
  }, [cv]);

  // Auto save theme preference to local storage
  useEffect(() => {
    localStorage.setItem(THEME_STORAGE_KEY, isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  const handleToggleAppTheme = () => {
    setIsDarkMode((prev) => !prev);
  };

  const handleLoadSample = () => {
    if (confirm(cv.lang === 'fr' ? 'Charger les données d\'exemple pré-remplies ?' : 'Load sample pre-filled data?')) {
      setCv(cv.lang === 'fr' ? { ...sampleCVFr } : { ...sampleCVEn });
    }
  };

  const handleClear = () => {
    if (confirm(cv.lang === 'fr' ? 'Réinitialiser tous les champs du CV ?' : 'Clear all CV fields?')) {
      setCv({ ...emptyCVState, lang: cv.lang });
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cv, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `CV_${cv.personal.lastName || 'MonCV'}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (importedData: CVData) => {
    setCv(importedData);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportPdf = async () => {
    setIsExportingPdf(true);
    try {
      const fileName = `CV_${cv.personal.firstName || 'Nom'}_${cv.personal.lastName || 'Prenom'}`;
      await exportToPdf('cv-preview-container', fileName);
    } catch (err) {
      console.error('PDF Export Error:', err);
      alert(cv.lang === 'fr' ? 'Erreur lors de l\'exportation en PDF.' : 'Error exporting PDF.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleExportImage = async () => {
    setIsExportingImage(true);
    try {
      const fileName = `CV_${cv.personal.firstName || 'Nom'}_${cv.personal.lastName || 'Prenom'}`;
      await exportToImage('cv-preview-container', fileName, 'png');
    } catch (err) {
      console.error('Image Export Error:', err);
      alert(cv.lang === 'fr' ? 'Erreur lors de l\'exportation en Image.' : 'Error exporting Image.');
    } finally {
      setIsExportingImage(false);
    }
  };

  const handleToggleLang = () => {
    const nextLang = cv.lang === 'fr' ? 'en' : 'fr';
    if (cv.personal.firstName === 'Alexandre' || !cv.personal.firstName) {
      setCv(nextLang === 'fr' ? { ...sampleCVFr } : { ...sampleCVEn });
    } else {
      setCv({ ...cv, lang: nextLang });
    }
  };

  const atsResult = evaluateAtsScore(cv);

  return (
    <div className={`min-h-screen flex flex-col font-sans-inter transition-colors duration-200 ${
      isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
    }`}>
      {/* Top Bar */}
      <Header
        cv={cv}
        isDarkMode={isDarkMode}
        onToggleAppTheme={handleToggleAppTheme}
        onLoadSample={handleLoadSample}
        onClear={handleClear}
        onExportJson={handleExportJson}
        onImportJson={handleImportJson}
        onPrint={handlePrint}
        onExportPdf={handleExportPdf}
        onExportImage={handleExportImage}
        onToggleLang={handleToggleLang}
        onOpenAtsModal={() => setIsAtsModalOpen(true)}
        atsScore={atsResult.score}
        isExportingPdf={isExportingPdf}
        isExportingImage={isExportingImage}
      />

      {/* Main Workspace Layout (Editor on Left, Live Preview on Right) */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden">
        {/* Left Form Editor Panel (5 Cols) */}
        <section className="lg:col-span-5 h-[calc(100vh-61px)] overflow-hidden">
          <EditorPanel cv={cv} onChange={setCv} isDarkMode={isDarkMode} />
        </section>

        {/* Right Live Preview Canvas (7 Cols) */}
        <section className={`lg:col-span-7 p-4 md:p-8 flex justify-center items-start overflow-y-auto max-h-[calc(100vh-61px)] transition-colors duration-200 ${
          isDarkMode ? 'bg-slate-950' : 'bg-slate-300/60'
        }`}>
          <div className="max-w-[210mm] w-full">
            <CVPreview cv={cv} />
          </div>
        </section>
      </main>

      {/* ATS Analysis Modal */}
      <AtsCheckerModal
        cv={cv}
        isOpen={isAtsModalOpen}
        onClose={() => setIsAtsModalOpen(false)}
        isDarkMode={isDarkMode}
      />
    </div>
  );
}
