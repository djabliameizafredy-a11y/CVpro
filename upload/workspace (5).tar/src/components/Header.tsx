import React, { useState } from 'react';
import { 
  FileText, 
  Wand2, 
  Trash2, 
  Printer, 
  Globe, 
  Sparkles,
  Image as ImageIcon,
  FileType,
  ChevronDown,
  Loader2,
  Sun,
  Moon
} from 'lucide-react';
import { CVData } from '../types';

interface HeaderProps {
  cv: CVData;
  isDarkMode?: boolean;
  onToggleAppTheme?: () => void;
  onLoadSample: () => void;
  onClear: () => void;
  onExportJson?: () => void;
  onImportJson?: (data: CVData) => void;
  onPrint: () => void;
  onExportPdf: () => void;
  onExportImage: () => void;
  onToggleLang: () => void;
  onOpenAtsModal: () => void;
  atsScore: number;
  isExportingPdf?: boolean;
  isExportingImage?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  cv,
  isDarkMode = true,
  onToggleAppTheme,
  onLoadSample,
  onClear,
  onPrint,
  onExportPdf,
  onExportImage,
  onToggleLang,
  onOpenAtsModal,
  atsScore,
  isExportingPdf = false,
  isExportingImage = false
}) => {
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);

  const getScoreBadgeColor = (score: number) => {
    if (score >= 85) return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    if (score >= 60) return 'bg-amber-500/20 text-amber-400 border-amber-500/30';
    return 'bg-rose-500/20 text-rose-400 border-rose-500/30';
  };

  const btnBgClass = isDarkMode
    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
    : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300';

  return (
    <header className={`no-print px-4 md:px-6 py-3 flex flex-wrap justify-between items-center gap-3 sticky top-0 z-50 border-b transition-colors duration-200 shadow-md ${
      isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
    }`}>
      {/* Brand Title */}
      <div className="flex items-center gap-3">
        <div className="bg-gradient-to-tr from-blue-600 to-sky-500 text-white p-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center justify-center">
          <FileText className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className={`font-extrabold text-lg tracking-tight leading-none ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
              CV Builder
            </h1>
            <span className="bg-blue-500/20 text-blue-500 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-500/30 uppercase tracking-widest">
              Pro
            </span>
          </div>
          <p className={`text-xs mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            {cv.lang === 'fr' ? 'Créateur de CV interactif & export PDF/Image' : 'Interactive CV Builder & PDF/Image Export'}
          </p>
        </div>
      </div>

      {/* Middle: ATS Score Indicator */}
      <button
        onClick={onOpenAtsModal}
        className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition hover:scale-105 ${getScoreBadgeColor(
          atsScore
        )}`}
        title={cv.lang === 'fr' ? 'Cliquez pour voir l\'analyse ATS' : 'Click to view ATS score analysis'}
      >
        <Sparkles className="w-3.5 h-3.5" />
        <span>ATS Score: {atsScore}%</span>
      </button>

      {/* Right Controls */}
      <div className="flex items-center gap-2 flex-wrap">
        {/* App Theme Toggle (Light / Dark Mode) */}
        {onToggleAppTheme && (
          <button
            onClick={onToggleAppTheme}
            className={`${btnBgClass} text-xs font-semibold px-2.5 py-2 rounded-lg border transition flex items-center gap-1.5`}
            title={
              cv.lang === 'fr'
                ? (isDarkMode ? 'Passer en Mode Clair' : 'Passer en Mode Sombre')
                : (isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode')
            }
          >
            {isDarkMode ? (
              <Sun className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Moon className="w-3.5 h-3.5 text-indigo-600" />
            )}
            <span className="hidden sm:inline font-medium">
              {cv.lang === 'fr'
                ? (isDarkMode ? 'Mode Clair' : 'Mode Sombre')
                : (isDarkMode ? 'Light Mode' : 'Dark Mode')}
            </span>
          </button>
        )}

        {/* Language Toggle */}
        <button
          onClick={onToggleLang}
          className={`${btnBgClass} text-xs font-semibold px-2.5 py-2 rounded-lg border transition flex items-center gap-1.5`}
          title={cv.lang === 'fr' ? 'Changer la langue (FR/EN)' : 'Switch language (FR/EN)'}
        >
          <Globe className="w-3.5 h-3.5 text-sky-500" />
          <span>{cv.lang.toUpperCase()}</span>
        </button>

        {/* Sample Data */}
        <button
          onClick={onLoadSample}
          className={`${btnBgClass} text-xs font-semibold px-3 py-2 rounded-lg border transition flex items-center gap-1.5`}
        >
          <Wand2 className="w-3.5 h-3.5 text-amber-500" />
          <span className="hidden md:inline">{cv.lang === 'fr' ? 'Exemple' : 'Sample'}</span>
        </button>

        {/* Clear */}
        <button
          onClick={onClear}
          className={`${btnBgClass} text-xs font-semibold px-3 py-2 rounded-lg border transition flex items-center gap-1.5`}
          title={cv.lang === 'fr' ? 'Réinitialiser le formulaire' : 'Clear all fields'}
        >
          <Trash2 className="w-3.5 h-3.5 text-rose-500" />
          <span className="hidden lg:inline">{cv.lang === 'fr' ? 'Vider' : 'Clear'}</span>
        </button>

        {/* Export Dropdown Group */}
        <div className="relative">
          <div className="inline-flex rounded-lg shadow-lg shadow-blue-600/20">
            <button
              onClick={onExportPdf}
              disabled={isExportingPdf || isExportingImage}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-3.5 py-2 rounded-l-lg transition flex items-center gap-2 active:scale-95 disabled:opacity-50"
            >
              {isExportingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileType className="w-4 h-4" />
              )}
              <span>{cv.lang === 'fr' ? 'Télécharger PDF' : 'Download PDF'}</span>
            </button>
            
            <button
              onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
              className="bg-blue-700 hover:bg-blue-600 text-white px-2 py-2 rounded-r-lg border-l border-blue-500/50 transition flex items-center justify-center"
              title={cv.lang === 'fr' ? 'Plus d\'options d\'export' : 'More export options'}
            >
              <ChevronDown className={`w-4 h-4 transition-transform ${isExportMenuOpen ? 'rotate-180' : ''}`} />
            </button>
          </div>

          {/* Export Dropdown Menu */}
          {isExportMenuOpen && (
            <div 
              className={`absolute right-0 mt-2 w-52 rounded-xl shadow-2xl z-50 py-1 overflow-hidden border ${
                isDarkMode ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
              }`}
              onMouseLeave={() => setIsExportMenuOpen(false)}
            >
              <button
                onClick={() => {
                  setIsExportMenuOpen(false);
                  onExportPdf();
                }}
                disabled={isExportingPdf}
                className={`w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 transition disabled:opacity-50 ${
                  isDarkMode ? 'hover:bg-slate-700 hover:text-white text-slate-200' : 'hover:bg-slate-100 hover:text-slate-900 text-slate-700'
                }`}
              >
                {isExportingPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                ) : (
                  <FileType className="w-4 h-4 text-blue-500" />
                )}
                <div>
                  <div className="font-semibold">{cv.lang === 'fr' ? 'Document PDF (.pdf)' : 'PDF Document (.pdf)'}</div>
                  <div className={`text-[10px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {cv.lang === 'fr' ? 'Format vectoriel prêt à imprimer' : 'Print-ready vector format'}
                  </div>
                </div>
              </button>

              <button
                onClick={() => {
                  setIsExportMenuOpen(false);
                  onExportImage();
                }}
                disabled={isExportingImage}
                className={`w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 transition border-t disabled:opacity-50 ${
                  isDarkMode
                    ? 'border-slate-700/50 hover:bg-slate-700 hover:text-white text-slate-200'
                    : 'border-slate-200 hover:bg-slate-100 hover:text-slate-900 text-slate-700'
                }`}
              >
                {isExportingImage ? (
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
                ) : (
                  <ImageIcon className="w-4 h-4 text-emerald-500" />
                )}
                <div>
                  <div className="font-semibold">{cv.lang === 'fr' ? 'Image HD (.png)' : 'HD Image (.png)'}</div>
                  <div className={`text-[10px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {cv.lang === 'fr' ? 'Haute définition 300 DPI' : 'High resolution 300 DPI'}
                  </div>
                </div>
              </button>

              <button
                onClick={() => {
                  setIsExportMenuOpen(false);
                  onPrint();
                }}
                className={`w-full text-left px-4 py-2.5 text-xs flex items-center gap-2.5 transition border-t ${
                  isDarkMode
                    ? 'border-slate-700/50 hover:bg-slate-700 hover:text-white text-slate-200'
                    : 'border-slate-200 hover:bg-slate-100 hover:text-slate-900 text-slate-700'
                }`}
              >
                <Printer className="w-4 h-4 text-amber-500" />
                <div>
                  <div className="font-semibold">{cv.lang === 'fr' ? 'Imprimer / Aperçu' : 'Print / Native Preview'}</div>
                  <div className={`text-[10px] ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {cv.lang === 'fr' ? 'Dialogue d\'impression système' : 'System print dialog'}
                  </div>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

