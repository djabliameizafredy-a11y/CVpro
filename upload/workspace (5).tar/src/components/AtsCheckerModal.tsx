import React from 'react';
import { X, CheckCircle2, AlertCircle, Sparkles, Trophy, Lightbulb } from 'lucide-react';
import { evaluateAtsScore, actionVerbsFr, actionVerbsEn } from '../data/aiHelpers';
import { CVData } from '../types';

interface AtsCheckerModalProps {
  cv: CVData;
  isOpen: boolean;
  onClose: () => void;
  isDarkMode?: boolean;
}

export const AtsCheckerModal: React.FC<AtsCheckerModalProps> = ({ cv, isOpen, onClose, isDarkMode = true }) => {
  if (!isOpen) return null;

  const result = evaluateAtsScore(cv);
  const actionVerbs = cv.lang === 'fr' ? actionVerbsFr : actionVerbsEn;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in ${
      isDarkMode ? 'bg-slate-950/80' : 'bg-slate-900/50'
    }`}>
      <div className={`border rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-6 ${
        isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        
        {/* Header */}
        <div className={`flex justify-between items-center border-b pb-4 ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-500/10 text-blue-500 rounded-xl border border-blue-500/20">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-lg font-bold ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                {cv.lang === 'fr' ? 'Analyse ATS & Score de CV' : 'ATS Analysis & CV Score'}
              </h2>
              <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {cv.lang === 'fr' ? 'Optimisez votre CV pour passer les filtres automatiques' : 'Optimize your resume to pass automated recruitment filters'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-2 rounded-lg transition ${
              isDarkMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Score Ring / Card */}
        <div className={`border rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-6 ${
          isDarkMode ? 'bg-slate-800/60 border-slate-700/60' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-4">
            <div className={`relative flex items-center justify-center w-20 h-20 rounded-full border-4 border-blue-500 text-2xl font-black shadow-inner ${
              isDarkMode ? 'bg-slate-900 text-white' : 'bg-white text-slate-900'
            }`}>
              {result.score}%
            </div>
            <div>
              <div className={`text-xs font-semibold uppercase tracking-wider ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {cv.lang === 'fr' ? 'Évaluation Globale' : 'Overall Assessment'}
              </div>
              <div className={`text-xl font-bold capitalize mt-0.5 ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>
                {result.level === 'excellent' && (cv.lang === 'fr' ? 'Excellent 🚀' : 'Excellent 🚀')}
                {result.level === 'good' && (cv.lang === 'fr' ? 'Très bon 👍' : 'Great Job 👍')}
                {result.level === 'average' && (cv.lang === 'fr' ? 'Moyen ⚠️' : 'Average ⚠️')}
                {result.level === 'needs_work' && (cv.lang === 'fr' ? 'À compléter 📝' : 'Needs Work 📝')}
              </div>
              <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                {result.score >= 80 
                  ? (cv.lang === 'fr' ? 'Votre CV comporte tous les éléments clés pour être bien indexé par les ATS.' : 'Your resume meets all key criteria for high indexing.')
                  : (cv.lang === 'fr' ? 'Complétez les sections ci-dessous pour augmenter vos chances d\'entretien.' : 'Complete the missing sections below to improve your chances.')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-amber-500 text-xs bg-amber-500/10 px-3 py-2 rounded-lg border border-amber-500/20 font-semibold shrink-0">
            <Trophy className="w-4 h-4 shrink-0" />
            <span>{cv.lang === 'fr' ? 'Format A4 compatible' : 'A4 Ready Format'}</span>
          </div>
        </div>

        {/* Checks List */}
        <div className="space-y-3">
          <h3 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
            {cv.lang === 'fr' ? 'Points de contrôle' : 'Checklist Criteria'}
          </h3>
          <div className="grid gap-2.5">
            {result.checks.map((c) => (
              <div
                key={c.id}
                className={`p-3.5 rounded-xl border flex items-start gap-3 transition ${
                  c.passed
                    ? isDarkMode
                      ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-200'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : isDarkMode
                      ? 'bg-slate-800/50 border-slate-700/80 text-slate-300'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                {c.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                )}
                <div className="text-xs flex-1">
                  <div className={`font-bold flex justify-between items-center ${
                    c.passed
                      ? isDarkMode ? 'text-emerald-100' : 'text-emerald-900'
                      : isDarkMode ? 'text-white' : 'text-slate-900'
                  }`}>
                    <span>{c.label}</span>
                    <span className="text-[10px] font-mono opacity-80">+{c.points} pts</span>
                  </div>
                  {!c.passed && (
                    <p className={`mt-1 leading-relaxed ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{c.recommendation}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended Action Verbs */}
        <div className={`border rounded-xl p-4 space-y-2 ${
          isDarkMode ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex items-center gap-2 text-xs font-bold text-sky-500 uppercase tracking-wider">
            <Lightbulb className="w-4 h-4" />
            <span>{cv.lang === 'fr' ? 'Verbes d\'action recommandés' : 'Recommended Action Verbs'}</span>
          </div>
          <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-600'}`}>
            {cv.lang === 'fr'
              ? 'Utilisez ces verbes puissants en début de puces pour décrire vos réussites :'
              : 'Start your bullet points with these strong action verbs:'}
          </p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {actionVerbs.map((verb) => (
              <span
                key={verb}
                className={`border px-2.5 py-1 rounded-md text-xs font-medium ${
                  isDarkMode
                    ? 'bg-slate-900 text-sky-300 border-slate-700'
                    : 'bg-white text-sky-700 border-slate-200 shadow-2xs'
                }`}
              >
                {verb}
              </span>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
