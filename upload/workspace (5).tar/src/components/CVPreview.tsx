import React from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Github, 
  Linkedin, 
  Globe, 
  Car, 
  Code2, 
  Briefcase, 
  GraduationCap, 
  Award, 
  UserCheck,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { CVData } from '../types';

interface CVPreviewProps {
  cv: CVData;
}

export const CVPreview: React.FC<CVPreviewProps> = ({ cv }) => {
  const { personal, skills, projects, education, languages, customSections, theme } = cv;

  const primaryBg = theme.primaryColor || '#0f172a';
  const accentColor = theme.accentColor || '#0284c7';

  // Font class resolver
  const getFontClass = () => {
    switch (theme.fontFamily) {
      case 'serif': return 'font-serif-lora';
      case 'mono': return 'font-mono-fira';
      default: return 'font-sans-inter';
    }
  };

  // Density padding classes
  const getDensityClass = () => {
    switch (theme.density) {
      case 'compact': return { pad: 'p-5', gap: 'space-y-3', text: 'text-[11px]', heading: 'text-xs' };
      case 'spacious': return { pad: 'p-8', gap: 'space-y-6', text: 'text-xs', heading: 'text-sm' };
      default: return { pad: 'p-6', gap: 'space-y-4', text: 'text-xs', heading: 'text-xs' };
    }
  };

  const density = getDensityClass();
  const defaultAvatarSvg = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='1.5'><path d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/><circle cx='12' cy='7' r='4'/></svg>";

  /* TEMPLATE 1: MODERN (Sidebar on left) */
  if (theme.template === 'modern') {
    return (
      <div id="cv-preview-container" className={`cv-paper-container cv-paper-a4 w-full bg-white text-slate-800 shadow-2xl rounded-lg overflow-hidden border border-slate-200 grid grid-cols-12 min-h-[297mm] ${getFontClass()}`}>
        {/* SIDEBAR (Col 4) */}
        <aside
          className="col-span-4 text-white p-6 flex flex-col justify-between transition-colors duration-300"
          style={{ backgroundColor: primaryBg }}
        >
          <div>
            {/* Photo & Identity */}
            <div className="flex flex-col items-center text-center mb-6">
              {theme.showPhoto && (
                <div className="relative w-28 h-28 mb-3">
                  <img
                    src={personal.photoUrl || defaultAvatarSvg}
                    alt="Profil"
                    className="w-28 h-28 rounded-full object-cover border-4 border-white/20 shadow-xl bg-slate-800"
                  />
                </div>
              )}
              <h1 className="text-base font-extrabold uppercase tracking-wide text-white break-words w-full">
                {personal.firstName || (cv.lang === 'fr' ? 'Prénom' : 'First Name')}
              </h1>
              <h2 className="text-sm font-extrabold uppercase tracking-widest text-white mb-1 break-words w-full">
                {personal.lastName || (cv.lang === 'fr' ? 'Nom' : 'Last Name')}
              </h2>
              {personal.nationality && (
                <p className="text-[10px] font-medium text-white bg-white/20 px-2.5 py-0.5 rounded-full border border-white/20 mt-1 inline-block">
                  {personal.nationality} {personal.drivingLicense ? `• ${personal.drivingLicense}` : ''}
                </p>
              )}
            </div>

            {/* Contacts */}
            <div className="mb-5 border-t border-white/20 pt-4">
              <h3 className="text-[11px] font-bold uppercase tracking-wider mb-2.5 text-white">
                Contact
              </h3>
              <ul className="space-y-2 text-[11px] text-white/95">
                {personal.address && (
                  <li className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 shrink-0 text-white/90" />
                    <span className="truncate">{personal.address}</span>
                  </li>
                )}
                {personal.phone && (
                  <li className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 shrink-0 text-white/90" />
                    <span>{personal.phone}</span>
                  </li>
                )}
                {personal.email && (
                  <li className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 shrink-0 text-white/90" />
                    <span className="break-all">{personal.email}</span>
                  </li>
                )}
                {personal.github && (
                  <li className="flex items-center gap-2">
                    <Github className="w-3.5 h-3.5 shrink-0 text-white/90" />
                    <span className="break-all">{personal.github}</span>
                  </li>
                )}
                {personal.linkedin && (
                  <li className="flex items-center gap-2">
                    <Linkedin className="w-3.5 h-3.5 shrink-0 text-white/90" />
                    <span className="break-all">{personal.linkedin}</span>
                  </li>
                )}
              </ul>
            </div>

            {/* Skills */}
            {skills.length > 0 && (
              <div className="mb-5 border-t border-white/20 pt-4">
                <h3 className="text-[11px] font-bold uppercase tracking-wider mb-2.5 text-white">
                  {cv.lang === 'fr' ? 'Compétences Tech' : 'Tech Skills'}
                </h3>
                <div className="space-y-2.5 text-[11px]">
                  {skills.map((s) => {
                    const tags = s.tags.split(',').filter(t => t.trim() !== '');
                    return (
                      <div key={s.id}>
                        <span className="text-white/90 font-semibold block mb-1 text-[10px]">{s.category}</span>
                        <div className="flex flex-wrap gap-1">
                          {tags.map((t, idx) => (
                            <span key={idx} className="bg-white/20 text-white px-2 py-0.5 rounded text-[10px] font-medium border border-white/10">
                              {t.trim()}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Languages */}
            {languages.length > 0 && (
              <div className="border-t border-white/20 pt-4">
                <h3 className="text-[11px] font-bold uppercase tracking-wider mb-2.5 text-white">
                  {cv.lang === 'fr' ? 'Langues' : 'Languages'}
                </h3>
                <ul className="space-y-1.5 text-[11px] text-white/95">
                  {languages.map((l) => (
                    <li key={l.id} className="flex justify-between items-center">
                      <span className="font-semibold">{l.name}</span>
                      <span className="text-white/80 text-[10px]">{l.level}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="text-[9px] text-white/80 pt-4 border-t border-white/10 text-center uppercase tracking-widest">
            {cv.lang === 'fr' ? 'Document Officiel' : 'Official Resume'}
          </div>
        </aside>

        {/* MAIN COLUMN (Col 8) */}
        <main className={`col-span-8 ${density.pad} bg-white flex flex-col justify-between`}>
          <div className={density.gap}>
            {/* Header Banner */}
            <div className="border-b-2 border-slate-200 pb-3">
              <h2 className="text-lg font-black text-slate-900 uppercase tracking-tight">
                {personal.jobTitle || (cv.lang === 'fr' ? 'Titre du Poste' : 'Job Title')}
              </h2>
              <p className="font-semibold text-xs mt-0.5 transition-colors" style={{ color: accentColor }}>
                {personal.subTitle || (cv.lang === 'fr' ? 'Spécialité & Domaine' : 'Specialization')}
              </p>
            </div>

            {/* Profile Summary */}
            {personal.summary && (
              <section>
                <h3
                  className="text-[11px] font-bold uppercase tracking-wider text-slate-800 bg-slate-100 px-2.5 py-1.5 rounded mb-2 flex items-center gap-1.5 border-l-4 transition-all"
                  style={{ borderLeftColor: accentColor }}
                >
                  <UserCheck className="w-3.5 h-3.5" style={{ color: accentColor }} />
                  <span>{cv.lang === 'fr' ? 'Profil Professionnel' : 'Professional Summary'}</span>
                </h3>
                <p className="text-xs text-slate-700 leading-relaxed bg-slate-50/80 p-3 rounded-lg border border-slate-100">
                  {personal.summary}
                </p>
              </section>
            )}

            {/* Projects & Experience */}
            {projects.length > 0 && (
              <section>
                <h3
                  className="text-[11px] font-bold uppercase tracking-wider text-slate-800 bg-slate-100 px-2.5 py-1.5 rounded mb-2.5 flex items-center gap-1.5 border-l-4 transition-all"
                  style={{ borderLeftColor: accentColor }}
                >
                  <Briefcase className="w-3.5 h-3.5" style={{ color: accentColor }} />
                  <span>{cv.lang === 'fr' ? 'Projets & Expériences' : 'Projects & Experiences'}</span>
                </h3>
                <div className="space-y-3">
                  {projects.map((p) => (
                    <div key={p.id} className="border-l-2 pl-3 py-0.5 transition-all" style={{ borderLeftColor: accentColor }}>
                      <div className="flex justify-between items-baseline gap-2">
                        <h4 className="font-bold text-slate-900 text-xs">
                          {p.title} {p.companyOrClient ? <span className="font-normal text-slate-600">• {p.companyOrClient}</span> : ''}
                        </h4>
                        {p.tag && (
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded text-white shadow-sm" style={{ backgroundColor: accentColor }}>
                            {p.tag}
                          </span>
                        )}
                      </div>
                      {p.startDate && <div className="text-[10px] text-slate-500 font-medium mb-1">{p.startDate}</div>}
                      <p className="text-xs text-slate-700 leading-normal">{p.desc}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {education.length > 0 && (
              <section>
                <h3
                  className="text-[11px] font-bold uppercase tracking-wider text-slate-800 bg-slate-100 px-2.5 py-1.5 rounded mb-2 flex items-center gap-1.5 border-l-4 transition-all"
                  style={{ borderLeftColor: accentColor }}
                >
                  <GraduationCap className="w-3.5 h-3.5" style={{ color: accentColor }} />
                  <span>{cv.lang === 'fr' ? 'Cursus Académique' : 'Education'}</span>
                </h3>
                <div className="space-y-2.5">
                  {education.map((e) => (
                    <div key={e.id} className="flex justify-between items-start text-xs border-b border-slate-100 pb-2 last:border-none">
                      <div>
                        <h4 className="font-bold text-slate-900">{e.degree}</h4>
                        <p className="text-slate-700 text-[11px]">{e.school}</p>
                        {e.details && <p className="text-[10px] text-slate-500 italic mt-0.5">{e.details}</p>}
                      </div>
                      <span className="text-[10px] text-slate-500 font-semibold whitespace-nowrap">{e.period}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Custom Sections */}
            {customSections.map((sec) => (
              <section key={sec.id}>
                <h3
                  className="text-[11px] font-bold uppercase tracking-wider text-slate-800 bg-slate-100 px-2.5 py-1.5 rounded mb-2 flex items-center gap-1.5 border-l-4 transition-all"
                  style={{ borderLeftColor: accentColor }}
                >
                  <Award className="w-3.5 h-3.5" style={{ color: accentColor }} />
                  <span>{sec.title}</span>
                </h3>
                <div className="space-y-1.5 text-xs">
                  {sec.items.map((it) => (
                    <div key={it.id} className="flex justify-between items-center text-slate-800 bg-slate-50 px-2.5 py-1.5 rounded border border-slate-100">
                      <span className="font-semibold">{it.title}</span>
                      <span className="text-[10px] text-slate-600">{it.subtitle}</span>
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </div>

          {/* Footer Bar */}
          <div className="border-t border-slate-100 pt-3 mt-4 flex justify-between items-center text-[10px] text-slate-600">
            {personal.qualities && (
              <div><span className="font-bold text-slate-800">Atouts :</span> {personal.qualities}</div>
            )}
            {personal.availability && (
              <div className="font-bold text-white px-2.5 py-0.5 rounded shadow-sm" style={{ backgroundColor: accentColor }}>
                {personal.availability}
              </div>
            )}
          </div>
        </main>
      </div>
    );
  }

  /* TEMPLATE 2: MINIMALIST (Single-column clean with colored header banner) */
  if (theme.template === 'minimalist') {
    return (
      <div id="cv-preview-container" className={`cv-paper-container cv-paper-a4 w-full bg-white text-slate-800 shadow-2xl rounded-lg overflow-hidden border border-slate-200 min-h-[297mm] flex flex-col justify-between ${getFontClass()}`}>
        <div>
          {/* Top Banner Header with Background Color */}
          <div className="p-6 text-white flex justify-between items-start transition-colors duration-300" style={{ backgroundColor: primaryBg }}>
            <div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-white">
                {personal.firstName} {personal.lastName}
              </h1>
              <h2 className="text-sm font-bold uppercase tracking-widest text-white/90 mt-1">
                {personal.jobTitle}
              </h2>
              {personal.subTitle && <p className="text-xs text-white/80 mt-0.5">{personal.subTitle}</p>}
            </div>

            <div className="text-right text-[11px] text-white/90 space-y-0.5">
              {personal.email && <div>{personal.email}</div>}
              {personal.phone && <div>{personal.phone}</div>}
              {personal.address && <div>{personal.address}</div>}
              {personal.github && <div>{personal.github}</div>}
            </div>
          </div>

          <div className="p-8 space-y-5">
            {/* Profile Summary */}
            {personal.summary && (
              <section>
                <h3
                  className="text-xs font-extrabold uppercase tracking-widest text-slate-800 bg-slate-100 px-3 py-1 rounded mb-2 inline-block border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'À propos' : 'Profile'}
                </h3>
                <p className="text-xs text-slate-700 leading-relaxed mt-1">
                  {personal.summary}
                </p>
              </section>
            )}

            {/* Skills Grid */}
            {skills.length > 0 && (
              <section>
                <h3
                  className="text-xs font-extrabold uppercase tracking-widest text-slate-800 bg-slate-100 px-3 py-1 rounded mb-2 inline-block border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'Compétences Techniques' : 'Technical Skills'}
                </h3>
                <div className="grid grid-cols-2 gap-3 text-xs mt-1">
                  {skills.map((s) => (
                    <div key={s.id} className="bg-slate-50 p-2.5 rounded border border-slate-100">
                      <span className="font-bold text-slate-900 block mb-1">{s.category}</span>
                      <p className="text-slate-700 text-[11px]">{s.tags}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Experience */}
            {projects.length > 0 && (
              <section>
                <h3
                  className="text-xs font-extrabold uppercase tracking-widest text-slate-800 bg-slate-100 px-3 py-1 rounded mb-3 inline-block border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'Expériences & Réalisations' : 'Experience & Projects'}
                </h3>
                <div className="space-y-3">
                  {projects.map((p) => (
                    <div key={p.id} className="text-xs border-l-2 pl-3" style={{ borderLeftColor: accentColor }}>
                      <div className="flex justify-between items-baseline font-bold text-slate-900">
                        <span>{p.title} {p.companyOrClient ? `— ${p.companyOrClient}` : ''}</span>
                        <span className="text-[10px] text-slate-500 font-normal">{p.startDate}</span>
                      </div>
                      <p className="text-slate-700 mt-0.5">{p.desc}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Education */}
            {education.length > 0 && (
              <section>
                <h3
                  className="text-xs font-extrabold uppercase tracking-widest text-slate-800 bg-slate-100 px-3 py-1 rounded mb-2 inline-block border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'Diplômes & Formations' : 'Education & Credentials'}
                </h3>
                <div className="space-y-2 text-xs mt-1">
                  {education.map((e) => (
                    <div key={e.id} className="flex justify-between items-baseline border-b border-slate-100 pb-1.5">
                      <div>
                        <span className="font-bold text-slate-900">{e.degree}</span>
                        <span className="text-slate-600 ml-2">({e.school})</span>
                      </div>
                      <span className="text-[10px] text-slate-500">{e.period}</span>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t p-4 flex justify-between text-[10px] text-slate-600">
          <span>{personal.qualities}</span>
          <span>{personal.availability}</span>
        </div>
      </div>
    );
  }

  /* TEMPLATE 3 & 4 (EXECUTIVE / CREATIVE) Default Fallback with Executive Header */
  return (
    <div id="cv-preview-container" className={`cv-paper-container cv-paper-a4 w-full bg-white text-slate-800 shadow-2xl rounded-lg overflow-hidden border border-slate-200 min-h-[297mm] flex flex-col justify-between ${getFontClass()}`}>
      <div>
        {/* Executive Header Banner */}
        <div className="p-6 text-white text-center space-y-2 transition-colors duration-300" style={{ backgroundColor: primaryBg }}>
          <h1 className="text-2xl font-black uppercase tracking-wider text-white">
            {personal.firstName} {personal.lastName}
          </h1>
          <h2 className="text-xs font-bold uppercase tracking-widest text-white/90">
            {personal.jobTitle} {personal.subTitle ? `• ${personal.subTitle}` : ''}
          </h2>
          <div className="flex flex-wrap justify-center items-center gap-4 text-[10px] text-white/90 pt-2 border-t border-white/20">
            {personal.email && <span>✉️ {personal.email}</span>}
            {personal.phone && <span>📞 {personal.phone}</span>}
            {personal.address && <span>📍 {personal.address}</span>}
            {personal.github && <span>💻 {personal.github}</span>}
          </div>
        </div>

        {/* 2 Column Body */}
        <div className="p-6 grid grid-cols-12 gap-6">
          {/* Main Content (Col 8) */}
          <div className="col-span-8 space-y-4">
            {personal.summary && (
              <section className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <h3 className="text-xs font-bold uppercase text-slate-800 mb-1">
                  {cv.lang === 'fr' ? 'Profil Professionnel' : 'Professional Summary'}
                </h3>
                <p className="text-xs text-slate-700 leading-relaxed">{personal.summary}</p>
              </section>
            )}

            {projects.length > 0 && (
              <section className="space-y-2">
                <h3
                  className="text-xs font-bold uppercase text-slate-800 bg-slate-100 px-2.5 py-1 rounded border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'Expériences & Réalisations' : 'Experiences & Achievements'}
                </h3>
                {projects.map((p) => (
                  <div key={p.id} className="text-xs space-y-0.5 border-l-2 pl-2" style={{ borderLeftColor: accentColor }}>
                    <div className="flex justify-between font-bold text-slate-900">
                      <span>{p.title}</span>
                      <span className="text-[10px] font-normal text-slate-500">{p.startDate}</span>
                    </div>
                    <p className="text-slate-700 text-[11px]">{p.desc}</p>
                  </div>
                ))}
              </section>
            )}

            {education.length > 0 && (
              <section className="space-y-2">
                <h3
                  className="text-xs font-bold uppercase text-slate-800 bg-slate-100 px-2.5 py-1 rounded border-l-4"
                  style={{ borderLeftColor: accentColor }}
                >
                  {cv.lang === 'fr' ? 'Formation' : 'Education'}
                </h3>
                {education.map((e) => (
                  <div key={e.id} className="text-xs flex justify-between">
                    <div>
                      <div className="font-bold text-slate-900">{e.degree}</div>
                      <div className="text-[10px] text-slate-600">{e.school}</div>
                    </div>
                    <span className="text-[10px] text-slate-500">{e.period}</span>
                  </div>
                ))}
              </section>
            )}
          </div>

          {/* Right Column (Col 4) */}
          <div className="col-span-4 space-y-4">
            {skills.length > 0 && (
              <section className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-2">
                <h3 className="text-xs font-bold uppercase text-slate-800">
                  {cv.lang === 'fr' ? 'Compétences' : 'Skills'}
                </h3>
                {skills.map((s) => (
                  <div key={s.id} className="text-xs">
                    <span className="font-bold text-slate-900 block text-[10px]">{s.category}</span>
                    <span className="text-slate-700 text-[10px]">{s.tags}</span>
                  </div>
                ))}
              </section>
            )}

            {languages.length > 0 && (
              <section className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-1">
                <h3 className="text-xs font-bold uppercase text-slate-800 mb-1">
                  {cv.lang === 'fr' ? 'Langues' : 'Languages'}
                </h3>
                {languages.map((l) => (
                  <div key={l.id} className="text-xs flex justify-between text-slate-800">
                    <span>{l.name}</span>
                    <span className="text-[10px] text-slate-600">{l.level}</span>
                  </div>
                ))}
              </section>
            )}
          </div>
        </div>
      </div>

      <div className="p-4 border-t text-center text-[10px] text-slate-500">
        CV Builder Professional Document
      </div>
    </div>
  );
};
